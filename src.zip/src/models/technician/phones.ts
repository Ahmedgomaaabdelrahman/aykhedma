export class Phone {
    constructor(public mobile: string, public technician_id : number) {
        this.mobile = mobile;
        this.technician_id = technician_id;
    }
  }