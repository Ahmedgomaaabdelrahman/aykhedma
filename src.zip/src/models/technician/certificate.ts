export class techCertificate {
    constructor(public image_url: string , public technician_id:number) {
        this.image_url = image_url ,
        this. technician_id = technician_id; 
      }
  }