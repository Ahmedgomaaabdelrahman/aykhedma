export class Skill {
    constructor(public id: number, public technician_id : number) {
        this.id = id;
        this.technician_id = technician_id;
    }
  }