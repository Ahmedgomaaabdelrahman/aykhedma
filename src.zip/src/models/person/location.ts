export class Location {
  constructor(public lat: number,
              public lng: number,
              public address: string) {
                
                this.lat = lat;
                this.lng = lng;
                this.address = address;

  }
}
