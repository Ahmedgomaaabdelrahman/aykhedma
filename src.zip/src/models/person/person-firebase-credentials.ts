export class PersonFBCredentials {
  constructor(public email: string,
              public password: string) {

  }
}
