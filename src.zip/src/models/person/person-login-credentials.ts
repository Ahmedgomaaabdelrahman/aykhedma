export class PersonLoginCred {
  constructor(public mobile: number,
              public password: string) {

  }
}
