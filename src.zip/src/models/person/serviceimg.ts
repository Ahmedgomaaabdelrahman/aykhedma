export class serviceImg {
    constructor(public service_url: string) {
      this.service_url = service_url;
    }
  }