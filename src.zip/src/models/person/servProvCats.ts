export class ServProviderCats {
    constructor(public service_category_id: number) {
      this.service_category_id = service_category_id;
    }
  }