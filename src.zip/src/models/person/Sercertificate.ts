export class servCertificate {
    constructor(public company_certificate_url: string) {
      this.company_certificate_url = company_certificate_url;
    }
  }