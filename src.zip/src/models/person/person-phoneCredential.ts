export class PhoneCred {
constructor(public mobile: number) {

}
}