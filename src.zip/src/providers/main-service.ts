export class MainService{
  public static lang :string='en';
  public static baseUrl : string = "http://anyserviceappksa.com/api/";
  public static imageUrl : string = "http://anyserviceappksa.com/";
}
